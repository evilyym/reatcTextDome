nvm -v 查看当前版本
nvm --config 
nvm list 查看已安装node版本列表
nvm install 版本号 下载对应node版本（如：nvm install 16.13）
nvm use 版本号 切换node版本
nvm on 开启nvm
nvm off 关闭nvm