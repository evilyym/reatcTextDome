<template>
  <div class="head_div">
    <img src="../assets/bg2.png" class="header_title" alt="">
    <img src="../assets/1.png" class="img1" alt="">
  </div>

  <!-- <div class="inf_div">
    <div class="form_div"> -->
      <!-- <div class="form_item" v-for="(item, index) of form1" :key="index"> -->

        <!-- <div v-if="item.type != 'title' && item.notShow != 1"> -->
          <!-- <div class="form_title">
            <span v-if="item.required">*</span>
            <span v-else></span>
            <div>{{ item.name }}</div>
          </div> -->
          <!-- <div class="form_input" v-if="item.type == 'input'">
            <input type="text" :maxlength="item.max" v-model="fromInf[item.prop]" :placeholder='item.placeholder' />

          </div> -->
          <!-- <div v-if="item.type == 'upImg'" class="">
            <div class="form_upImg">
              <van-uploader v-model="fromInf[item.prop]" :after-read="item.afterRead" :max-count="item.maxCount" />
            </div>

            <div class="tip" v-if="item.tip">
              {{ item.tip }}</div>
          </div> -->
        <!-- </div> -->
        <!-- <div v-if="item.type == 'title' && item.notShow != 1">
          <div class="inf_title_div">
            {{ item.title }}</div>
        </div> -->
      <!-- </div> -->
    <!-- </div> -->
    <!-- <div class="but_box">
      <div class="but_div" @click="onSubmit">提交 </div>
    </div>
  </div> -->

  <van-form v-if="true" @submit="onSubmit" class="formBox" :show-error="true" :show-error-message="false"
    error-message-align="right" label-align="top">
    <van-cell-group inset>
      <van-field v-model="username" name="姓名" label="姓名" placeholder="姓名" required
        :rules="[{ pattern, message: '请填写姓名' }]" />
      <van-field v-model="password" name="手机号" label="手机号" placeholder="请填写手机号" required
        :rules="[{ required: true, message: '请填写手机号' }]" />
      <van-field v-model="password" name="身份证" label="身份证" placeholder="请填写密码" required
        :rules="[{ required: true, message: '请填写身份证' }]" />
      <van-field v-model="result1" readonly name="密码" label="来访时间" placeholder="请填写密码" required
        :rules="[{ required: true, message: '请填写密码' }]" />
      <van-field label="离开时间" required v-model="result" is-link readonly name="datePicker" placeholder="点击选择时间"
        @click="showPicker = true" :rules="[{ required: true, message: '请填写离开时间' }]" />
      <van-field v-model="password" name="密码" label="车牌号" placeholder="请填写车牌号" required
        :rules="[{ required: true, message: '请填写密码' }]" />
      <van-field name="uploader" required label="车辆照片">
        <template #input>
          <van-uploader v-model="fiel" multiple max-count="1" />
        </template>
      </van-field>
    </van-cell-group>
    <div style="margin: 16px">
      <van-button round block type="primary" native-type="submit">
        提交表单
      </van-button>
    </div>
  </van-form>
  <nut-popup v-model:show="showPicker" position="bottom">
    <nut-date-picker v-model="currentDate" title="日期时间选择" type="datetime" :min-date="minDate" :max-date="maxDate"
      @confirm="confirm"></nut-date-picker>
  </nut-popup>
</template>
<script lang="ts" setup>
import { ref } from "vue";
import axios from "axios";
// const fromInf = ref({
//   code: '',
//   health: '',
//   health_remarks: '',
//   name: '',
//   visitor_unit: '',
//   phone: '',
//   id_card: '',
//   visitor_at: '',
//   car_number: '',
//   health_status: '',
//   dep_id: '',
//   visited_name: '',
//   visited_phone: '',
//   subject_id: '',
//   remarks: '',
//   // img_list: '',
//   health_code: '',
//   // report_img: '',
//   imgList: [],
//   imgList2: [],
//   // imgList3: [],
// })
// const form = ref<any>([
//   {
//     type: 'title',
//     no_audit_show: 1,
//     notShow: 1,
//     title: '完善访客信息'
//   },
//   {
//     type: 'input',
//     name: '访客姓名',
//     required: true,
//     notShow: 1,
//     list: '',
//     placeholder: '请输入访客姓名',
//     no_audit_show: 1,
//     prop: 'name'
//   },])
// const form1 = () => {
//   return form.value.filter(i => { return i.no_audit_show == 1 })
// }
// old
var nowDate = new Date();
const username = ref("");
const password = ref("");
const pattern = /^(?:[\u4e00-\u9fa5·]{2,16})$/;
const fiel = ref([
  // { url: 'https://fastly.jsdelivr.net/npm/@vant/assets/leaf.jpeg' },
]);

const result = ref("");
const result1 = ref(nowDate.getFullYear() + "-" + (nowDate.getMonth() + 1) + "-" + nowDate.getDay() + " " + nowDate.getHours() + ":" + nowDate.getMinutes());
const showPicker = ref(false);

const minDate = new Date();
const maxDate = new Date(minDate.getFullYear() + 2, minDate.getMonth(), 1);
const currentDate = new Date();

// let date = {
//   year: nowDate.getFullYear(),
//   month: nowDate.getMonth() + 1
// };
const confirm = ({ selectedValue }: { selectedValue: any }) => {
  const date = selectedValue.slice(0, 3).join("-");
  const time = selectedValue.slice(3).join(":");
  console.log(selectedValue);
  result.value = (date + " " + time);
  showPicker.value = false
};

const onSubmit = (values: any) => {
  axios
    .get("/user?ID=" + values)
    .then(function (response: any) {
      // 处理成功情况
      console.log(response);
    })
    .catch(function (error: any) {
      // 处理错误情况
      console.log(error);
    })
    .then(function () {
      // 总是会执行
    });
};
</script>
<style lang="less">
.formBox {
  padding: 20px 10px;
  border: 2px solid #eee;
  border-radius: 10px;
}

.head_div {
  height: 200px;
  background: url(../assets/bg.png) no-repeat;
  background-size: 100%;
  display: flex;
  padding: 0 74px;
  align-items: center;
  position: relative;

  .img1 {
    position: absolute;
    top: 27px;
    right: 64px;
    z-index: 12;
    height: 230px;
  }

  .header_title {
    height: 50px;
  }
}
</style>
