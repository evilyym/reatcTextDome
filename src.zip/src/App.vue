<template>
    <VS />
</template>
<script lang="ts" setup>
import VS from "./page/index.vue";
</script>
<style>
html,body{
  margin: 0;padding: 0;
  background-color: #fff;
  color-scheme:unset;
  font-size: 14px;
}</style>
